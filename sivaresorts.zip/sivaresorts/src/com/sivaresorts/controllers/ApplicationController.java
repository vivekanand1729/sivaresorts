package com.sivaresorts.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ApplicationController {
	
	@RequestMapping("/sivaresorts")
	public ModelAndView openHomePage() {

		return new ModelAndView("home");
	}
	@RequestMapping("/hello")
	public ModelAndView helloWorld() {

		String message = "Welcome to Siva Resorts!";
		return new ModelAndView("hello", "message", message);
	}

}
